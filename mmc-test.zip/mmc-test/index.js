// Immediate execution - no dependencies
(function() {
    // Create banner immediately
    const banner = document.createElement('div');
    banner.id = 'mmc-test-banner';
    banner.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: #ff00ff;
        color: white;
        padding: 15px;
        font-size: 18px;
        font-weight: bold;
        z-index: 999999;
        text-align: center;
    `;
    banner.textContent = 'MMC TEST: Script is running! ' + new Date().toLocaleTimeString();
    
    // Try multiple ways to add it
    if (document.body) {
        document.body.appendChild(banner);
    } else {
        document.addEventListener('DOMContentLoaded', () => {
            document.body.appendChild(banner);
        });
    }
    
    // Also try after a delay
    setTimeout(() => {
        if (!document.getElementById('mmc-test-banner')) {
            document.body.appendChild(banner);
        }
        banner.textContent += ' | Still running at ' + new Date().toLocaleTimeString();
    }, 2000);
    
    // Log to console too
    console.log('=== MMC TEST EXTENSION LOADED ===');
})();
